=== Giveaway Engine ===
Contributors: plusplusmins
Tags: giveaway, social giveaways.
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 1.4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

= 1.0.0 =
* Initial release. Woo!
